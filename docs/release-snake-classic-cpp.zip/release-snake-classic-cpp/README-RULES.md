- Movimento
Muovi il serpente con le frecce direzionali (← ↑ → ↓).
Premi Shift per aumentare la velocità del serpente.

- Regole
Se la testa del serpente tocca uno dei bordi della finestra, la partita termina.
Se la testa del serpente colpisce una qualsiasi altra parte del suo corpo, la partita termina.

